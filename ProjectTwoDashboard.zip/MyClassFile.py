from pymongo import MongoClient
from bson.objectid import ObjectId

class DatabaseLayer(object):
    """
    Class definition:
    The purpose of this class is to encapsulate all the details of connecting and accessing a
    Mongo database. This class will be used in a Web based app.
    """

    def __init__(self, host, port, username, password):
        """
        Constructor: specify all user/host credentials.
        Initialize self attributes.
        """
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        
        # Store all credentials in a single URI.
        self.uri = 'mongodb://' + username + ':' + password + '@' + host + ':' + port + '/AAC'
        
        # Display the login credentials in URI format.
        print(self.uri)

    def connect(self, logging=False):
        """
        Method to implement the authentication and connection to the MongoDB.
        """
        self.connection = MongoClient(self.uri)
        if logging:
            # Equivalent to 'show dbs' in Mongo shell -- verifies successful connection.
            print(self.connection.list_database_names())

    def setDatabase(self, database):
        """
        Method to set the current MongoDB database for CRUD operations.
        """
        # Sets connection to the MongoDB.
        self.db = self.connection[database]

    def create(self, collection, data=None):
        """
        Inserts a new document into the MongoDB.
        Implements the 'C' in CRUD.
        """
        if data is not None and data:
            # Insert entered data into selected collection.
            inserted_data = self.db[collection].insert_one(data)
            
            # Check for acknowledgement of insertion from MongoDB.
            if inserted_data.acknowledged:
                return True  # Return True with successful insertion
            else:
                return False  # Return False with unsuccessful insertion
        else:
            # Raise exception if no data is entered.
            raise Exception("Document(s) NOT created--No data entered.")

    def read(self, collection, filter=None):
        """
        Method to filter and find document(s) in MongoDB.
        Implements the 'R' in CRUD.
        """
        # Get the collection.
        c = self.db[collection]
        
        # Get cursor with filtered documents.
        cursor = c.find(filter)
        
        # Generate a list of documents.
        return list(cursor)

    def update(self, collection, filter, update_data):
        """
        Method to update filtered document(s) with specified change data.
        Implements the 'U' in CRUD.
        """
        # Assigns collection to a variable.
        u = self.db[collection]
        
        # Assigns filtered data set to variable.
        # Updates selected fields.
        result = u.update_many(filter, {'$set': update_data})
        
        # Counts the number of changed documents to user.
        return result.modified_count

    def delete(self, collection, filter=None):
        """
        Method to delete filtered document(s).
        Implements the 'D' in CRUD.
        """
        # Assigns the collection to a variable.
        d = self.db[collection]
        
        # Assigns filtered data for deletion from the collection to a variable.
        result = d.delete_many(filter)
        
        # Provides the user a count of deleted documents.
        return result.deleted_count
